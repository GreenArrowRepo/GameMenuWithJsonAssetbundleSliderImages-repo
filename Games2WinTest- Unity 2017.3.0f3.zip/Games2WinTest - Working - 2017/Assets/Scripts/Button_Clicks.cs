﻿/// <summary> Unity ver. used 2017.3.0f3
/// Button clicks.
/// - This Script is attached in 'sampleSceneF' which is the main menu scene.
/// - This scrit has button's event code.When clicked on button, executes function related to clicked button.
/// 
/// - when clicked on '?' button it will download the 'helpscene' assetbundle from server and will open help scene on top of the current scene.
/// - when clicked on 'steering' button it will download the 'imageslidescene' asset bundle and will open imageslide scene on top of the current scene.
/// - when clicked on button with the 'W logo', the user will be taken to the Games2Win website (www.games2win.com).  

/// - When asset bundle scene is open on the current scene and if user presses back button it will go back to controls(menu) scene. 
/// 
/// - The music, sfx and sensitivity sliders are interactable user can keep the slider to whichever value they want and when the project is quit and 
///   restarted or the scene is changed and returned to the given scene, the user’s values should reflect back.
/// - Visual cues are added when the Steering, Touch Controls, Tilt and Flip Controls buttons are used.
/// 
/// Managing JSON file 'data.json'
/// - Link of the json file which is 'data.json' is uploade here http://himanshumaisuriya.000webhostapp.com/win2gametest/data.json". 
/// - You can change the data.json file link in 'DataController' script
/// - You can Edit 'data.json' file in UnityEditor by accessing Window->Game Data Editor
/// - edit json file using editor and upload it on server and specify that link in Datacontroller script.
/// 
/// Help Scene AssetBundle Link
/// - Link for helpScene assetbundle is http://himanshumaisuriya.000webhostapp.com/win2gametest/helpscene
/// - you can change this link in this script.
/// 
/// Image Slider AsseetBundle Link
/// - Link for imageslider scene asset bundle is http://himanshumaisuriya.000webhostapp.com/win2gametest/imageslidescene
/// 
/// -control selection(steering, touch, tilt)Clicks are determined dynamically at run time and game control will get selected and highlighted with 'Green back Image' 
///  with 'SELECTED' text at runtime.
/// 
/// 
/// </summary>
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using UnityEngine.UI;
using UnityEngine.Networking;
using UnityEngine.SceneManagement;

public class Button_Clicks : MonoBehaviour {

	[SerializeField]
	private Sprite[] s1;

	[SerializeField]
	private GameObject[] buts;

	[SerializeField]
	private Toggle m_Toggle;

	[SerializeField]
	private Button[] butssss;

	[SerializeField]
	private Sprite greenImg;

	[SerializeField]
	private Sprite yellowImg;

	[SerializeField]
	private Image[] selectImages;

	[SerializeField]
	private Image manualSelectImg;

	[SerializeField]
	private Text manualText;

	[SerializeField]
	public Slider steeringSenSilder, musicSlider, sfxSlider;

	string bname;
	int bnameint;

	bool toggleimg, loadAssetBundleOnce;

	private AssetBundleCreateRequest bundleRequest;
	private UnityWebRequest request;
	private AssetBundle bundle;

	private UnityWebRequest steeringRequest;
	private AssetBundle steeringAssetbundle;

	List<Button> buttonsList = new List<Button>();


	void Start()
	{
		//Fetch the Toggle GameObject
	//	m_Toggle = ToggleObj.gameObject.GetComponent<Toggle>();

		SceneManager.sceneUnloaded += OnSceneUnloaded;
		//Add listener for when the state of the Toggle changes, to take action
		m_Toggle.onValueChanged.AddListener(delegate {
			ToggleValueChanged(m_Toggle);
		});

		//Initialise the Text to say the first state of the Toggle
		//Debug.Log("First Value : " + m_Toggle.isOn);

		// add buttons in list
		for (int j = 0; j < butssss.Length; j++) {
			buttonsList.Add (butssss [j]);
		}

		// fetch all slider's value from playerprefab if set by user
		steeringSenSilder.value = PlayerPrefs.GetFloat ("steeringSenSliderVal");
		musicSlider.value = PlayerPrefs.GetFloat ("musicsliderVal");
		sfxSlider.value = PlayerPrefs.GetFloat ("sfxsliderVal");

		//Adds a listener to sliders and invokes a method when the value changes.
		steeringSenSilder.onValueChanged.AddListener(delegate {ValueChangeCheck(); });
		musicSlider.onValueChanged.AddListener(delegate {ValueChangeCheck(); });
		sfxSlider.onValueChanged.AddListener(delegate {ValueChangeCheck(); });


			// send request to download helpscene assetbundle..
		request = UnityWebRequest.GetAssetBundle ("http://himanshumaisuriya.000webhostapp.com/win2gametest/helpscene");
		request.Send ();
		

		// send request to download helpscene assetbundle..
		steeringRequest = UnityWebRequest.GetAssetBundle ("http://himanshumaisuriya.000webhostapp.com/win2gametest/imageslidescene");
		steeringRequest.Send ();

		toggleimg = false;
		AddListeners ();
	}


	//Output the new state of the Toggle into Text
	void ToggleValueChanged(Toggle change)
	{
		if (m_Toggle.isOn) 
		{
			buts[0].GetComponent<Image> ().sprite = s1 [0];
			buts[1].GetComponent<Image> ().sprite = s1 [2];
			buts[2].GetComponent<Image> ().sprite = s1 [4];
		} else 
		{
			buts[0].GetComponent<Image> ().sprite = s1 [1];
			buts[1].GetComponent<Image> ().sprite = s1 [3];
			buts[2].GetComponent<Image> ().sprite = s1 [5];
		}
	}

	//when value of sliders is changed..saving it locally.
	public void ValueChangeCheck()
	{
		PlayerPrefs.SetFloat("steeringSenSliderVal", steeringSenSilder.value);
		PlayerPrefs.SetFloat("musicsliderVal", musicSlider.value);
		PlayerPrefs.SetFloat("sfxsliderVal", sfxSlider.value);
	}

	// Add listners on control buttons steering, touch and tilt
	void AddListeners ()
	{
		foreach (Button btn in buttonsList) {
			btn.onClick.AddListener (() => OnButtonClick ());
		}
	}


	// clicks are determined dynamically at run time and game control will get selected and highlighted with green image and selected text at runtime.
	public void OnButtonClick()
	{
		
		bname = UnityEngine.EventSystems.EventSystem.current.currentSelectedGameObject.name;
		bnameint = int.Parse (bname);

		foreach (Button b in buttonsList) 
		{
			for (int i = 0; i < butssss.Length; i++) 
			{
				if (bnameint == i) 
				{
					selectImages [bnameint].sprite = greenImg;
					butssss [bnameint].GetComponentInChildren<Text> ().text = "SELECTED";
				}
			}
		}

		switch (bnameint) 
		{
		case 0:
			selectImages [1].sprite = yellowImg;
			butssss [1].GetComponentInChildren<Text> ().text = "SELECT";
			selectImages [2].sprite = yellowImg;
			butssss [2].GetComponentInChildren<Text> ().text = "SELECT";

			break;
		case 1:
			selectImages [0].sprite = yellowImg;
			butssss [0].GetComponentInChildren<Text> ().text = "SELECT";
			selectImages [2].sprite = yellowImg;
			butssss [2].GetComponentInChildren<Text> ().text = "SELECT";
			break;
		case 2:
			selectImages [0].sprite = yellowImg;
			butssss [0].GetComponentInChildren<Text> ().text = "SELECT";
			selectImages [1].sprite = yellowImg;
			butssss [1].GetComponentInChildren<Text> ().text = "SELECT";
			break;
		}
			
	}

	public void OnOffManualContol()
	{
		toggleimg = !toggleimg;
		if (toggleimg) {
			manualSelectImg.sprite = greenImg;
			manualText.text = "ON";
		} else {
			manualSelectImg.sprite = yellowImg;
			manualText.text = "OFF";
		}

	}

	// when clicked on 'W logo' button will open the specified link
	public void openURLW()
	{
		Application.OpenURL ("http://www.games2win.com");
	}

	//When clicked on help 
	public void helpButtonClick()
	{
		
		//Open help scene from downloaded asset bundle 
		if (request.isDone) 
		{	
			bundle = DownloadHandlerAssetBundle.GetContent (request);
			SceneManager.LoadScene ("helpScene_Assetbundle");
		}
	}

	//SteeringButtonClck
	public void steeringButtonClick()
	{
		

		//Open help scene from downloaded asset bundle 
		if (steeringRequest.isDone) 
		{
			steeringAssetbundle = DownloadHandlerAssetBundle.GetContent (steeringRequest);
			SceneManager.LoadScene ("persistant");
		}

	}

	// unload loaded bundle when scene is unloaded 
	private void OnSceneUnloaded(Scene current)
	{
		if (current.name == "helpScene_Assetbundle") {
			bundle.Unload (false);
			//Debug.Log ("helpscene unloaded");
		}
		//Debug.Log("OnSceneUnloaded: " + current.name);
	}


}

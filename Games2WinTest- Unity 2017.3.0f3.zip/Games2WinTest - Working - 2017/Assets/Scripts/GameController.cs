﻿/// <summary>
///This script is for loading game images,game names, and game description from the server.
///This script accesses the AllData Script and its variable and displays images,naems and description.
///
/// 
/// Created by Himanhu Maisuriya
/// </summary>

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using UnityEngine.Networking;
using System.IO;

public class GameController : MonoBehaviour {


	private DataController datacontroller;
	private GameNameData gameNamed;
	private GameDescData gDescription;
	private AllData allDataPool;

	private int nameIndex;

	//public GameObject imagePrefab;
	public Transform imagesParent;

	[SerializeField]
	private GameObject[] go;
	int count;

	private AssetBundleCreateRequest bundleRequest;
	private UnityWebRequest request;
	string url;
	Sprite[] mysprite;

	[SerializeField]
	Text[] textObj, textObjDesc;

	public static List<Sprite> downloadedTexture = new List<Sprite> ();


	IEnumerator Start()
	{
		datacontroller = FindObjectOfType<DataController> ();
		allDataPool = datacontroller.getAllGamesData ();
		gameNamed = allDataPool.gname;
		gDescription = allDataPool.gdesc;

	

		// create thumbnails runtime
		for (int i = 0; i < datacontroller.allGameData.Length; i++) 
		{
			
			using (WWW www = new WWW (datacontroller.allGameData[i].tpath.gamethumbText)) /////////
			{
				yield return www;
				if(!string.IsNullOrEmpty(www.error))
				{
					Debug.Log(www.error);
					yield break;
				}
				//downloadedTexture.Add (www.texture);
				downloadedTexture.Add (Sprite.Create (www.texture, new Rect (0.0f, 0.0f, www.texture.width, www.texture.height), new Vector2 (0.5f, 0.5f), 100.0f));
			}

			go[i].gameObject.GetComponent<Image>().sprite = downloadedTexture[i];


		}

		ShowName (); //show image names and descriptions
	}

	//show image name and Description of the image from json data... 
	void ShowName()
	{
		for (int j = 0; j < datacontroller.allGameData.Length; j++) 
		{
			textObj [j].GetComponent<Text> ().text = datacontroller.allGameData [j].gname.gameNameText;
			textObjDesc [j].GetComponent<Text> ().text = datacontroller.allGameData [j].gdesc.GameDescText;
		}
	}

}



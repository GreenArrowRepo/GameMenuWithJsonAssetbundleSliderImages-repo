﻿/// <summary>
/// This script contains the user defined datatype named'GameDescData' and its variable named'GameDescText'.
/// 
/// Created by Himanhu Maisuriya
/// </summary>

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class GameDescData {
	public string GameDescText; // will store gameDescription in this
}

﻿/// <summary>
/// This script contains the array of all json variables 
/// 
/// Created by Himanhu Maisuriya
/// </summary>

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class GameData {

    public AllData[] allGameData;
}

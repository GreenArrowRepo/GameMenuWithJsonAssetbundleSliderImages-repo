﻿/// <summary>
/// This script contains the user defined datatype named'GameNameData' and its variable named'gameNameText'.
/// 
/// Created by Himanhu Maisuriya
/// </summary>
/// 
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class GameNameData {
   
    public string gameNameText; // will store game name in this

}

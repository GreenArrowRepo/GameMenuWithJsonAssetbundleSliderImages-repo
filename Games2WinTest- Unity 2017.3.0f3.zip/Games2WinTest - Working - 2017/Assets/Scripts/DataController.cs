﻿/// <summary>
/// Data controller.
/// This is the important script attached in persistant scene. This will be the part of ImageSlide Assetbundle.
/// This script accesses the data.json file and stores the data in AllData script's variables.
/// Once the json data is fetched and stored in AllData variables the scene changes to ImageslideScene
/// datacontroller object stays alive when persistant scene is changed to ImageSlidescene which is named as MainScene.
/// </summary>

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using System.IO;
using UnityEngine.Networking;

public class DataController : MonoBehaviour {
    [SerializeField]
	public  AllData[] allGameData;

    private WWW www;

    private string gameDataFileName = "ImageSliderdata.json";

    IEnumerator Start()
    {
        DontDestroyOnLoad(gameObject);
        //

		UnityWebRequest www = UnityWebRequest.Get("http://himanshumaisuriya.000webhostapp.com/win2gametest/ImageSliderdata.json");
        yield return www.SendWebRequest();

        if (www.isNetworkError || www.isHttpError)
        {
            Debug.Log(www.error);
        }
        else
        {
            // Show results as text
            Debug.Log(www.downloadHandler.text);
            LoadGameData(www.downloadHandler.text);

            // Or retrieve results as binary data
            byte[] results = www.downloadHandler.data;
        }
    
    //

		SceneManager.LoadScene("GImagesSlide");
    }

	public AllData getAllGamesData()
    {
		return allGameData[0]; // need to use for loop here to get the data of more then one games
	}

    private void LoadGameData(string filepath)
    {
        
        //string filepath = Path.Combine(Application.streamingAssetsPath, gameDataFileName);
        
		//if (File.Exists (filepath))
		//{
			//string dataAsJason = File.ReadAllText (filepath);
			GameData loadedData = JsonUtility.FromJson<GameData> (filepath);

			allGameData = loadedData.allGameData;
		/*} 
		else 
		{
			Debug.LogError ("can't load game data!");
		}*/
    }

   
}

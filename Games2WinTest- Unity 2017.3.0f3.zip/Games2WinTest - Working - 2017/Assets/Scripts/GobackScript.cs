﻿/// <summary>
/// Persistant go.
/// This script is attached on 'persistant' scene which is part of ImageSlide assetbundle.
/// This script keeps the GameObject alive when asset bundle is loaded on current scene and user can go back by pressing 
/// back button on mobile.
/// </summary>
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GobackScript : MonoBehaviour {

	void Update () {
        if (Input.GetKey(KeyCode.Escape))
        {
            SceneManager.LoadScene(0);

            return;
        }
    }
}

﻿/// <summary>
/// This script contains All user defined datatype named GameDescData,GameNameData,GameThumbImgData and its variable which will store Game description, game description and path 
/// of the image in gdesc, gname, tpath variable respectively and will these variable values in data.json file.
/// 
/// Created by Himanhu Maisuriya
/// </summary>
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class AllData {
	public GameDescData gdesc;
    public GameNameData gname;
	public GameThumbImgData tpath; // image thumb path 


}

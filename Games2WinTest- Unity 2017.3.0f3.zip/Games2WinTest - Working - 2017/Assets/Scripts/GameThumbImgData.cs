﻿/// <summary>
/// This script contains the user defined datatype named'GameThumbImgData' and its variable named'gamethumbText'.
/// 
/// Created by Himanhu Maisuriya
/// </summary>

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class GameThumbImgData {
	public string gamethumbText; //will store link of image in this
}

﻿/// <summary>
/// Persistant go.
/// this script is attached on persistant_scene. This script keeps the GameObject alive when asset bundle is loaded on current scene and user can go back by pressing 
/// back button on mobile.
/// </summary>
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Persistant_go : MonoBehaviour {

	void Start () {
		DontDestroyOnLoad (gameObject);
		SceneManager.LoadScene ("GameMenu");
	}
	
	void Update()
	{
		if (Input.GetKey(KeyCode.Escape))
		{
			SceneManager.LoadScene(0);
			return;
		}
	}
}
